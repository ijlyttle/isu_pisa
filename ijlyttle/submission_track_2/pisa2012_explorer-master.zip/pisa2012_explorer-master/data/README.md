# data

to get this to run, you will have to add `student2012.rda` and `student2012dict.rda` to the `data` directory.