This web application was created using [shiny](http://shiny.rstudio.com), an open-source framework to bring interactivity to analyses built using [R](http://www.r-project.org/).

The authors are:

* Ian Lyttle, Schneider Electric
* Alex Shum, Iowa State University and Schneider Electric
* Dianne Cook, Iowa State University
* Luke Fostvedt, Iowa State University

Source code is available at [GitHub](https://github.com/ijlyttle/pisa_explorer), 

This work is licensed under a [Creative Commons Attribution-ShareAlike 4.0 International License](http://creativecommons.org/licenses/by-sa/4.0/).

