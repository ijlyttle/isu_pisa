The two factors are selected: the presence of a quiet study place at a student's home, and how many televisions are at a student's home. 

The countries are grouped according the correlation of their students' math scores with respect to the number of televisions at home. The map is colored accordingly; the plot on the right shows the groups, countries, and median score in each country.

The plot on the left shows how many students belong to each category (group, study-place, # TV's).
The plot in the middle summarizes student performance in each category.

The countries where the numbers of TV's correlates with higher math-scores tend to be in the developing world, whereas those with the opposite trend tend to be in the developed world. There are, of course, exceptions.

On the contrary, having a quiet place to study generally correlates with higher math-scores.




